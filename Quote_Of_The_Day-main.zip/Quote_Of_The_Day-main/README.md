# Quote_Of_The_Day
<h3><b>A Beautiful Quote Of The Day Page Using HTML , CSS and JavaScript.</b></h3>
<br>

<b>This Project Contains:-</b>

<li>Header (Heading)</li>
<li>Main Contain (Sub-Heading, New Quote Button, Prints Random Quotes With Their Author Names)</li>
<br><br>

<b><i>This Quote Of The Day Page Is Fully Functional & Responsive.</i></b> 
<br><br><br>
![Screenshot (443)](https://user-images.githubusercontent.com/85762282/158265393-9223d194-0b6b-430b-ba92-168c5c993d9f.png)
<br><br>
![Screenshot (444)](https://user-images.githubusercontent.com/85762282/158265405-351c79af-7bec-41ad-9206-1f808c4f9170.png)
<br><br>
![Screenshot (445)](https://user-images.githubusercontent.com/85762282/158265409-e3580537-8a74-4947-8eac-d3379556384c.png)
<br><br>
<a href="https://kanha412.github.io/Quote_Of_The_Day/" target="_blank" style="text-decoration:none;"><i><b>Have A Look By Clicking Here</b></i></a>
